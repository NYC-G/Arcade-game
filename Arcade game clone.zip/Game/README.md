# Classic Arcade Game Clone

## Instructions

## How It Works

* The Classic Arcade Game Clone is a skill game.
* You get points for every time you get to the water.
* You are trying to move the avatar so that you do not meet the worm.
* When you meet the worm you losing point and back to the grass.


## How to Play - Keyboard

* *Left ←*   to move left
* *Right →*  to move right
* *Up ↑*     to move up
* *Down ↓*   to move down

### Installation & System

 * The game doesn't has high system requirements
 * The application works on all desktop, tablet and phone browsers.

 Have a fun!

 https://github.com/Rainbowski

 2018
